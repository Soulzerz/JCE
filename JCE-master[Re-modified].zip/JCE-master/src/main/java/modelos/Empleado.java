/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main.java.modelos;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.Column;
import javax.persistence.Table;
import javax.persistence.Id;
import javax.persistence.GeneratedValue;
import org.hibernate.annotations.Type;

/**
 *
 * @author developer
 */

@Entity
@Table(schema = "Seguridad",name = "Empleados")
public class Empleado
{
    //<editor-fold desc="Atributos">
    @Id
    @GeneratedValue
    @Column(name="ID_Empleado")
    private long id;
    
    @Column(name = "Nombre_Usuario",nullable = false,length = 25,unique = true)
    private String usuario;
    
    @Column(name = "password",nullable = false)
    private String password;
    
    @Column(name = "Autorizacion",nullable = false)
    private byte Autorizacion;
    
    @Column(name = "ID_Provincia")
    private Long idProvincia;
    
    @Column(name="ID_Usuario",nullable = true)
    private Long idUsuario;
    
    @Column(name = "Estado",nullable = false)
    @Type(type = "numeric_boolean")
    private boolean estado;
    
    private Date FechaCreacion;
    
    private Date FechaModificacion;
    //</editor-fold>
    
    //<editor-fold defaultstate="collapsed" desc="Getters y Setters">

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public byte getAutorizacion() {
        return Autorizacion;
    }

    public void setAutorizacion(byte Autorizacion) {
        this.Autorizacion = Autorizacion;
    }

    public Long getIdProvincia() {
        return idProvincia;
    }

    public void setIdProvincia(Long idProvincia) {
        this.idProvincia = idProvincia;
    }

    public Long getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(Long idUsuario) {
        this.idUsuario = idUsuario;
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    public Date getFechaCreacion() {
        return FechaCreacion;
    }

    public void setFechaCreacion(Date FechaCreacion) {
        this.FechaCreacion = FechaCreacion;
    }

    public Date getFechaModificacion() {
        return FechaModificacion;
    }

    public void setFechaModificacion(Date FechaModificacion) {
        this.FechaModificacion = FechaModificacion;
    }
    
    //</editor-fold>

    //<editor-fold defaultstate="collapsed" desc="Constructor">
    public Empleado() {
    }
    //</editor-fold>
}
