/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main.java.modelos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Soulz
 */
public class Testing {
    public static void Test() throws SQLException
    {
          Connection con = DriverManager.getConnection("jdbc:derby://localhost:1527/Clientes", "app", " ");
          Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
          String SQL = "SELECT * FROM [Seguridad].[Empleados]";
          ResultSet rs = stmt.executeQuery(SQL);
          while(rs.next())
          {
              System.out.println(rs.getString("[ID_Empleado]"));
          }
    }
    public static void main()throws SQLException
    {
        
    }
}
