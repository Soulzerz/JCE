/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main.java;

import java.util.List;
import javax.swing.table.TableModel;
import javax.swing.JTable;
import main.java.modelos.Partido;
import main.java.modelos.Empleado;
import main.java.Contexto.ContextoUsuario;
import javax.crypto.spec.PBEKeySpec;

/**
 *
 * @author Phenom
 */
public class Helper 
{
    /*public static void CargarPartidos(JTable tbl,List<Partido> lista)
    {
        tbl.setModel(new PartidoTableModel(lista));
    }
    
    public static void Cargar(JTable tbl,()List<Empleado> lista)
    {
        this.set
    }*/
    
    public static Empleado validarUsuario(Empleado emp)
    {
        ContextoUsuario cntx = new ContextoUsuario();
        List<Empleado> usuarios = cntx.seleccionarTodos();
        for(Empleado e:usuarios)
        {
            if(e.getUsuario().equals(emp.getUsuario()) && 
                    e.getPassword().equals(emp.getPassword()))
            {
                return e;
            }
        }
        return emp;
    }
}
