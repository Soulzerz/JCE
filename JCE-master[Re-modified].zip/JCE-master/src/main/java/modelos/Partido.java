/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main.java.modelos;

/**
 *
 * @author Victor D. Montero
 */
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.GeneratedValue;
import javax.persistence.Table;
import javax.persistence.ManyToOne;
import org.hibernate.annotations.Type;
import java.util.Date;
import javax.persistence.JoinColumn;

@Entity
@Table(schema = "Administracion",name = "Partidos")
public class Partido 
{
    //<editor-fold desc="Atributos">
    @Id
    @GeneratedValue
    @Column(name = "ID_Partido")
    private long id;
    
    @Column(name = "Numero_Orden")
    private int noOrden;
    
    @Column(length = 25,nullable = false,name= "Nombre")
    private String siglas;
    
    @Column(name="Descripcion")
    private String descripcion;
    
    @Column(name="Total_Votos")
    private long totalVotos;
    
    @ManyToOne
    @JoinColumn(name="ID_Usuario")
    private Empleado Empleados;
    
    @Column(name = "Estado",nullable = false)
    @Type(type = "numeric_boolean")
    private boolean estado;
    
    private Date FechaCreacion;
    
    private Date FechaModificacion;
    
    //</editor-fold>
    
    //<editor-fold defaultstate="collapsed" desc="Getters y Setters">
    public long getId() {
        return id;
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getSiglas() {
        return siglas;
    }

    public void setSiglas(String siglas) {
        this.siglas = siglas;
    }

    public long getTotalVotos() {
        return totalVotos;
    }

    public void setTotalVotos(long totalVotos) {
        this.totalVotos = totalVotos;
    }
    
    public Empleado getEmpleados() {
        return Empleados;
    }

    public void setEmpleados(Empleado Empleados) {
        this.Empleados = Empleados;
    }

    public Date getFechaCreacion() {
        return FechaCreacion;
    }

    public void setFechaCreacion(Date FechaCreacion) {
        this.FechaCreacion = FechaCreacion;
    }

    public Date getFechaModificacion() {
        return FechaModificacion;
    }

    public void setFechaModificacion(Date FechaModificacion) {
        this.FechaModificacion = FechaModificacion;
    }

    public int getNoOrden() {
        return noOrden;
    }

    public void setNoOrden(int noOrden) {
        this.noOrden = noOrden;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
    //</editor-fold>
    
    //<editor-fold defaultstate="collapsed" desc="Constructor">
    public Partido() {}
    //</editor-fold>
}
