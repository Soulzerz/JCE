/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main.java.Contexto;

/**
 *
 * @author developer
 */
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

public abstract class ContextoBase 
{
    private SessionFactory factory;
    private Session session;
    public ContextoBase(String NombreConf) throws HibernateException
    {
        Configuration conf = new Configuration();
        conf.configure(NombreConf);
        ServiceRegistryBuilder srBuilder = new ServiceRegistryBuilder();
        srBuilder.applySettings(conf.getProperties());
        ServiceRegistry sr = srBuilder.buildServiceRegistry();
        this.factory = conf.buildSessionFactory(sr);
    }
    
    public ContextoBase() throws HibernateException
    {
        Configuration conf = new Configuration();
        conf.configure();
        ServiceRegistryBuilder srBuilder = new ServiceRegistryBuilder();
        srBuilder.applySettings(conf.getProperties());
        ServiceRegistry sr = srBuilder.buildServiceRegistry();
        this.factory = conf.buildSessionFactory(sr);
    }

    public SessionFactory getFactory() {
        return factory;
    }

    public void setFactory(SessionFactory factory) {
        this.factory = factory;
    }
    
    public void abrirSession()
    {
        this.session = this.getFactory().openSession();
        Transaction tx = session.beginTransaction();
    }
    
    public void cerrarSession()
    {
        Transaction tx = session.getTransaction();
        tx.commit();
        session.close();
    }
    
}
