/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main.java;

/**
 *
 * @author developer
 */
import java.util.List;
import javax.swing.table.AbstractTableModel;
import main.java.modelos.Empleado;

public class UsuarioTableModel extends AbstractTableModel
{
    List<Empleado> empleados;
    Object[] columnas;

    public UsuarioTableModel(List<Empleado> empleados) {
        super();
        this.empleados = empleados;
    }

    @Override
    public int getRowCount() {
        return this.empleados.size();
    }

    @Override
    public int getColumnCount() {
        return this.empleados.getClass().getDeclaredFields().length;
    }

    @Override
    public Object getValueAt(int i, int i1) {
        Empleado emp = empleados.get(i);
        columnas = new Object[]{emp.getId(),emp.getUsuario(),
            emp.getPassword(),
            emp.getAutorizacion(),emp.getIdProvincia(),
        emp.getIdUsuario(),emp.isEstado(),emp.getFechaCreacion(),
        emp.getFechaModificacion()};
        return columnas[i1];
    }

    @Override
    public String getColumnName(int i) {
        return new Empleado().getClass().getDeclaredFields()[i].getName();
    }
    
    
}
