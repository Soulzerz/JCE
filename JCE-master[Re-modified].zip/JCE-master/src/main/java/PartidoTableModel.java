/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main.java;
import java.util.List;
import javax.swing.table.AbstractTableModel;
import main.java.Contexto.*;
import main.java.modelos.Partido;
/**
 *
 * @author Phenom
 */
@SuppressWarnings("unchecked")
public class PartidoTableModel extends AbstractTableModel
{
    private List<Partido> partidos;
    private Object[] columnas;

    public PartidoTableModel(List<Partido> partidos) 
    {
        super();
        this.partidos = partidos;
    }
    
    @Override
    public int getRowCount() {
        return partidos.size();
    }

    @Override
    public int getColumnCount() {
        return new Partido().getClass().getDeclaredFields().length-1;
    }

    @Override
    public Object getValueAt(int i, int i1) 
    {
        Partido p = partidos.get(i);
        this.columnas = new Object[]{p.getId(),p.getNombre(),
                                    p.getTotalVotos(),p.getIdUsuario(),p.isEstado(),
                                    p.getFechaCreacion(),p.getFechaModificacion()};
        return columnas[i1];
    }

    @Override
    public String getColumnName(int i) {
        return new Partido().getClass().getDeclaredFields()[i].getName();
    }

    
    
}
