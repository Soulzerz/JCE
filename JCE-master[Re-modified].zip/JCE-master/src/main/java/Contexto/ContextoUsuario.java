/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main.java.Contexto;

/**
 *
 * @author developer
 */

import main.java.modelos.Empleado;
import org.hibernate.Session;
import org.hibernate.Transaction;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Query;

public class ContextoUsuario extends ContextoBase implements IConsultable<Empleado>
{

    //<editor-fold defaultstate="collapsed" desc="Constructores">
    
    public ContextoUsuario(String NombreConf) throws HibernateException {
        super(NombreConf);
    }

    public ContextoUsuario() throws HibernateException {
        super();
    }
    
    //</editor-fold>

    //<editor-fold defaultstate="collapsed" desc="Metodos CRUD">
    @Override
    public void insertar(Empleado o) {
        Session ses = this.getFactory().openSession();
        Transaction tx = ses.beginTransaction();
        ses.persist(o);
        tx.commit();
        ses.close();
    }

    @Override
    public Empleado buscar(long Id) {
        Session ses = this.getFactory().openSession();
        Transaction tx = ses.beginTransaction();
        Query q = ses.createQuery("from Empleado e where e.id=:id");
        q.setLong("id",Id);
        Empleado p = (Empleado)q.uniqueResult();
        tx.commit();
        ses.close();
        return p;
    }

    @Override
    public List<Empleado> seleccionarTodos() {
        Session ses = this.getFactory().openSession();
        Transaction tx = ses.beginTransaction();
        Query query = ses.createQuery("from Empleado p "+
                                                "where p.estado=:estado");
        query.setBoolean("estado", true);
        List<Empleado> empleados = query.list();
        tx.commit();
        ses.close();
        return empleados;
    }

    @Override
    public void eliminar(int Id) {
        Session ses = this.getFactory().openSession();
        Transaction tx = ses.beginTransaction();
        Empleado p = this.buscar(Id);
        p.setEstado(false);
        ses.update(p);
        tx.commit();
        ses.close();
    }

    @Override
    public void actualizar(Empleado elem) {
        Session ses = this.getFactory().openSession();
        Transaction tx = ses.beginTransaction();
        ses.update(elem);
        tx.commit();
        ses.close();
    }
    
    //</editor-fold>
}
