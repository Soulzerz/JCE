/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main.java.modelos;

/**
 *
 * @author Victor D. Montero
 */
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.GeneratedValue;
import org.hibernate.annotations.Type;

@Entity
@Table(schema = "Administracion",name = "Alianzas")
public class Alianza 
{
    @Id
    @GeneratedValue
    private long id;
    
    
}
