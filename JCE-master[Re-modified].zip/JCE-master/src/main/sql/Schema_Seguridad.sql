USE [JCE]
GO

/****** Object:  Schema [Seguridad]    Script Date: 18/03/2016 07:43:44 a.m. ******/
DROP SCHEMA [Seguridad]
GO

/****** Object:  Schema [Seguridad]    Script Date: 18/03/2016 07:43:44 a.m. ******/
CREATE SCHEMA [Seguridad]
GO

