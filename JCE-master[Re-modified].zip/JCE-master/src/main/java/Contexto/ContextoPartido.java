/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main.java.Contexto;

/**
 * Contexto para las tablas partidos
 * @author developer
 * @param <T>
 */
import main.java.modelos.Partido;
import org.hibernate.Session;
import org.hibernate.Transaction;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Query;

public class ContextoPartido extends ContextoBase implements IConsultable<Partido>
{
    //<editor-fold defaultstate="collapsed" desc="Constructores">
    
    public ContextoPartido(String NombreConf) {
        super(NombreConf);
    }

    public ContextoPartido() {
        super();
    }

    //</editor-fold>
    
    //<editor-fold defaultstate="collapsed" desc="Metodos CRUD">
    
    @Override
    public void insertar(Partido o) throws HibernateException 
    {
        Session ses = this.getFactory().openSession();
        Transaction tx = ses.beginTransaction();
        ses.persist(o);
        tx.commit();
        ses.close();
    }
    
    @Override
    public Partido buscar(long Id) {
        Session ses = this.getFactory().openSession();
        Transaction tx = ses.beginTransaction();
        Query q = ses.createQuery("from Partido p where p.id=:id");
        q.setLong("id",Id);
        Partido p = (Partido)q.uniqueResult();
        tx.commit();
        ses.close();
        return p;
    }

    @Override
    public List<Partido> seleccionarTodos() {
        Session ses = this.getFactory().openSession();
        Transaction tx = ses.beginTransaction();
        Query query = ses.createQuery("from Partido p "+
                                                "where p.estado=:estado");
        query.setBoolean("estado", true);
        List<Partido> Partidos = query.list();
        tx.commit();
        ses.close();
        return Partidos;
    }

    @Override
    public void eliminar(int Id) throws HibernateException 
    {
        Session ses = this.getFactory().openSession();
        Transaction tx = ses.beginTransaction();
        Partido p = this.buscar(Id);
        p.setEstado(false);
        ses.update(p);
        tx.commit();
        ses.close();
    }

    @Override
    public void actualizar(Partido p) 
    {
        Session ses = this.getFactory().openSession();
        Transaction tx = ses.beginTransaction();
        ses.update(p);
        tx.commit();
        ses.close();
    }
    
    //</editor-fold>
}
