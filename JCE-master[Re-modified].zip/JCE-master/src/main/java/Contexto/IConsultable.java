/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main.java.Contexto;

import java.util.List;

/**
 * Interfaz que debe implementar todos los contextos
 * @author Victor D. Montero
 * @param <T> POJO o entidad con el que se trabajara en la implementacion 
 * de esta interfaz
 */
public interface IConsultable<T>
{
    /**
     * Inserta un POJO o entidad
     * @param o Entidad a insertar
     */
    public void insertar(T o);
    
    /**
     * Busca un POJO o entidad
     * @param Id Llave primaria de la entidad que se buscara
     * @return Entidad
     */
    public T buscar(long Id);
    
    /**
     * Retorna todos los POJOs o entidades
     * @return Entidades
     */
    public List<T> seleccionarTodos();
    
    /**
     * Elimina un POJO o entidad
     * @param Id Llave primaria de la entidad que se eliminara
     */
    public void eliminar(int Id);
    
    /**
     * Actualiza un POJO o entidad
     * @param elem Entidad a Actualizar
     */
    public void actualizar(T elem);
}
