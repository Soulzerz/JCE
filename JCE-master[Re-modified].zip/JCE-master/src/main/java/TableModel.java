/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main.java;
import java.util.List;
import javax.swing.table.AbstractTableModel;
import main.java.Contexto.*;
import main.java.modelos.Partido;
/**
 *
 * @author Phenom
 */
public class TableModel<T> extends AbstractTableModel
{
    private List<T> partidos;
    private Object[] columnas;

    public TableModel(List<T> elems) 
    {
        super();
        this.partidos = partidos;
    }
    
    @Override
    public int getRowCount() {
        return partidos.size();
    }

    @Override
    public int getColumnCount() {
        return getClass().getDeclaredFields().length-1;
    }

    @Override
    public Object getValueAt(int i, int i1) 
    {
        T p = partidos.get(i);
        byte num = (byte)p.getClass().getDeclaredFields().length;
        this.columnas = new Object[num];
        
        return columnas[i1];
    }
    
}
