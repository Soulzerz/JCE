USE [JCE]
GO

/****** Object:  Schema [Administracion]    Script Date: 18/03/2016 07:43:28 a.m. ******/
DROP SCHEMA [Administracion]
GO

/****** Object:  Schema [Administracion]    Script Date: 18/03/2016 07:43:28 a.m. ******/
CREATE SCHEMA [Administracion]
GO

